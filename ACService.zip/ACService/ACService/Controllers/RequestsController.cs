﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ACService.Controllers
{
    public class RequestsController : Controller
    {
        //private ACService aCServiceDBEntities;
        public IActionResult Index()
        {
            return View();
        }
    }
}
