﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ACService.Models
{
    public class Request
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ProblemDescription { get; set; }
        public string Address { get; set; }
        public string Image { get; set; }
        public int RequestStatus { get; set; }
        public DateTime Date { get; set; }
        public int TechnicianId { get; set; }
    }
}
